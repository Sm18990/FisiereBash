!#/bin/bash/

sudo apt update

sudo apt upgrade

sudo apt install wget

wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb

sudo dpkg -i google-chrome-stable_current_amd64.deb

google-chrome

sudo rm google-chrome-stable_current_amd64.deb
