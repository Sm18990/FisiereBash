!#/bin/bash

sudo apt update

sudo apt upgrade

sudo apt install default-jdk

sudo apt update

sudo apt install default-jre

java --version
