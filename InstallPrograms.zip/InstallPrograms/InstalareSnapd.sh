!#/bin/bash/


sudo mv /etc/apt/preferences.d/nosnap.pref ~/Documents/nosnap.backup

sudo apt update

sudo apt install snapd
