!#/bin/bash/

sudo apt update

sudo apt upgrade

sudo apt-get install gdebi-core

sudo wget https://github.com/shiftkey/desktop/releases/download/release-2.9.3-linux3/GitHubDesktop-linux-2.9.3-linux3.deb

sudo gdebi GitHubDesktop-linux-2.9.3-linux3.deb

