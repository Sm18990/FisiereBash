!#/bin/bash  

sudo apt update

sudo apt upgrade

sudo apt install build-essential

sudo apt-get install manpages-dev

sudo apt install codeblocks



