# FisiereBash

SnapD este pachetul care permite instalarea mai usoara de aplicatii, rulati mai intai instalarea snapd apoi celelalte fisiere

pentru a opri din rulare o comanda apasati Ctrl + C

# Pentru a instala programele:

1. Descarcati arhiva zip in pc->cand va apare tabul->selectati save file, nu open with
2. Navigati in downloads->selectati arhiva->click dreapta->extract here
3. Intrati in folderul extras
4. Apasati click dreapta pe un loc gol din pagina
5. Click stanga->open in terminal
6. Copiati comanda asta: sh InstallAllPrograms.sh
7. In temrinal->click dreapta->paste
8. Apasati enter si introduceti parola 
9. Cand apare un prompt pe linia de comanda cu y/n mereu apasati y si apoi enter
