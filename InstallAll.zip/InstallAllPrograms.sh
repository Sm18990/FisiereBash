!#/bin/bash/

sudo apt update 

sudo apt upgrade 

sh InstalareSnapd.sh

sh InstalareChrome.sh

sh InstalareGithub.sh

sh InstallCode::Blocks.sh

sh InstallDiscord.sh

sh InstallGit.sh

sh InstallJava.sh

sh InstallVsCode.sh

sh InstallZoom.sh 
