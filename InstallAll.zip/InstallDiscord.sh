!#/bin/bash?

sudo apt update

sudo apt upgrade

sudo snap install discord

